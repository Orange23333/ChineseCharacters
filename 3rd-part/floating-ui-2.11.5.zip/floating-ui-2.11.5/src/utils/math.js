// @flow
export const max = Math.max;
export const min = Math.min;
export const round = Math.round;
